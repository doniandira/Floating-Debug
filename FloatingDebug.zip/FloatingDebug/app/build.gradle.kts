import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Versi dibaca dari version.properties di akar proyek (mis. versionName=1.0.1).
// versionCode dihitung otomatis: 1.0.1 -> 10001, 1.2.0 -> 10200, 2.0.0 -> 20000.
val versionProps = Properties().apply {
    val f = rootProject.file("version.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val appVersionName: String = (versionProps.getProperty("versionName") ?: "1.0.0").trim()
val appVersionCode: Int = run {
    val parts = appVersionName.split(".").map { p -> p.filter { it.isDigit() }.toIntOrNull() ?: 0 }
    parts.getOrElse(0) { 0 } * 10000 + parts.getOrElse(1) { 0 } * 100 + parts.getOrElse(2) { 0 }
}

// Alamat repositori GitHub tempat update dicek (format "pemilik/nama-repo").
// Workflow mengisinya otomatis lewat -PupdateRepo=...
val updateRepo: String = (project.findProperty("updateRepo") as String?)
    ?: (versionProps.getProperty("updateRepo") ?: "")

android {
    namespace = "com.floatingdebug.network"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.floatingdebug.network"
        minSdk = 26
        targetSdk = 35
        versionCode = appVersionCode
        versionName = appVersionName

        buildConfigField("String", "UPDATE_REPO", "\"$updateRepo\"")

    }

    // Kunci tanda tangan tetap: semua versi (1.0.0, 1.0.1, ...) HARUS memakai kunci yang sama
    // agar Android mau memasang update di atas versi lama tanpa uninstall.
    signingConfigs {
        create("release") {
            storeFile = file("release.keystore")
            storeType = "pkcs12"
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "floatingdebug2026"
            keyAlias = "floatingdebug"
            keyPassword = System.getenv("KEY_PASSWORD") ?: "floatingdebug2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.fromTarget("17"))
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.12.0")
}
