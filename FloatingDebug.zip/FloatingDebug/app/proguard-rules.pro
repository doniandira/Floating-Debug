# JNI: nama kelas & method native harus tetap agar cocok dengan simbol di libfloating_imgui_debug.so
-keep class com.floatingdebug.network.jni.NativeBridge { *; }
