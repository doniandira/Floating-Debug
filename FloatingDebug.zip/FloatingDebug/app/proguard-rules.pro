# Tidak ada aturan khusus (proyek ini murni Kotlin, tanpa kode native).
