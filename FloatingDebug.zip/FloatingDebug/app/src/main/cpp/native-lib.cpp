/**
 * native-lib.cpp
 * JNI Bridge between Android Kotlin VpnService and C++ Dear ImGui render loop.
 */

#include <jni.h>
#include <string>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <android/log.h>
#include <mutex>
#include <vector>
#include <queue>
#include <memory>

#include "ImGuiOverlay.h"

#define LOG_TAG "FloatingDebugNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static ANativeWindow* g_NativeWindow = nullptr;
static std::unique_ptr<ImGuiOverlay> g_Overlay = nullptr;
static JavaVM* g_JavaVM = nullptr;
static jclass g_BridgeClass = nullptr;
static jmethodID g_ToggleBlockMethod = nullptr;

jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    g_JavaVM = vm;
    JNIEnv* env;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }

    // Cache Java callback method to trigger IP block in VpnService
    jclass localClass = env->FindClass("com/floatingdebug/network/jni/NativeBridge");
    g_BridgeClass = reinterpret_cast<jclass>(env->NewGlobalRef(localClass));
    g_ToggleBlockMethod = env->GetStaticMethodID(g_BridgeClass, "toggleIpBlockFromNative", "(Ljava/lang/String;Z)V");

    LOGI("JNI_OnLoad completed successfully.");
    return JNI_VERSION_1_6;
}

// C++ Callback invoked when user clicks "BLOCK" in the ImGui Window
void NativeToggleBlockCallback(const std::string& ip, bool block) {
    if (!g_JavaVM || !g_BridgeClass || !g_ToggleBlockMethod) return;

    JNIEnv* env = nullptr;
    g_JavaVM->AttachCurrentThread(&env, nullptr);
    if (env) {
        jstring jIp = env->NewStringUTF(ip.c_str());
        env->CallStaticVoidMethod(g_BridgeClass, g_ToggleBlockMethod, jIp, static_cast<jboolean>(block));
        env->DeleteLocalRef(jIp);
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_floatingdebug_network_jni_NativeBridge_initImGui(
        JNIEnv* env, jobject /* this */, jobject surface, jint width, jint height) {
    
    if (g_NativeWindow != nullptr) {
        ANativeWindow_release(g_NativeWindow);
        g_NativeWindow = nullptr;
    }

    g_NativeWindow = ANativeWindow_fromSurface(env, surface);
    if (!g_NativeWindow) {
        LOGE("Failed to obtain ANativeWindow from Java Surface");
        return JNI_FALSE;
    }

    g_Overlay = std::make_unique<ImGuiOverlay>();
    if (!g_Overlay->Init(g_NativeWindow, width, height, NativeToggleBlockCallback)) {
        LOGE("ImGuiOverlay initialization failed!");
        return JNI_FALSE;
    }

    LOGI("ImGuiOverlay successfully initialized (%dx%d)", width, height);
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_floatingdebug_network_jni_NativeBridge_onSurfaceChanged(
        JNIEnv* env, jobject /* this */, jint width, jint height) {
    if (g_Overlay) {
        g_Overlay->Resize(width, height);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_floatingdebug_network_jni_NativeBridge_renderFrame(
        JNIEnv* env, jobject /* this */) {
    if (g_Overlay) {
        g_Overlay->Render();
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_floatingdebug_network_jni_NativeBridge_destroyImGui(
        JNIEnv* env, jobject /* this */) {
    if (g_Overlay) {
        g_Overlay->Shutdown();
        g_Overlay.reset();
    }
    if (g_NativeWindow) {
        ANativeWindow_release(g_NativeWindow);
        g_NativeWindow = nullptr;
    }
    LOGI("ImGui Overlay destroyed.");
}

extern "C" JNIEXPORT void JNICALL
Java_com_floatingdebug_network_jni_NativeBridge_onTouchEvent(
        JNIEnv* env, jobject /* this */, jint action, jfloat x, jfloat y) {
    if (g_Overlay) {
        g_Overlay->HandleTouch(action, x, y);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_floatingdebug_network_jni_NativeBridge_pushNetworkMetric(
        JNIEnv* env, jobject /* this */,
        jstring srcIp, jint srcPort,
        jstring dstIp, jint dstPort,
        jstring protocol, jint packetSize,
        jboolean isBlocked) {

    if (!g_Overlay) return;

    const char* cSrc = env->GetStringUTFChars(srcIp, nullptr);
    const char* cDst = env->GetStringUTFChars(dstIp, nullptr);
    const char* cProto = env->GetStringUTFChars(protocol, nullptr);

    g_Overlay->RecordPacket(
        std::string(cSrc), srcPort,
        std::string(cDst), dstPort,
        std::string(cProto),
        packetSize,
        isBlocked
    );

    env->ReleaseStringUTFChars(srcIp, cSrc);
    env->ReleaseStringUTFChars(dstIp, cDst);
    env->ReleaseStringUTFChars(protocol, cProto);
}

extern "C" JNIEXPORT void JNICALL
Java_com_floatingdebug_network_jni_NativeBridge_onPacketDropped(
        JNIEnv* env, jobject /* this */,
        jstring ip, jint port, jstring protocol, jint length) {
    if (!g_Overlay) return;

    const char* cIp = env->GetStringUTFChars(ip, nullptr);
    const char* cProto = env->GetStringUTFChars(protocol, nullptr);

    g_Overlay->RecordDroppedPacket(std::string(cIp), port, std::string(cProto), length);

    env->ReleaseStringUTFChars(ip, cIp);
    env->ReleaseStringUTFChars(protocol, cProto);
}