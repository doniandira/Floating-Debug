/**
 * ImGuiOverlay.cpp
 * Strict Monochrome Theme & In-Game Floating HUD Implementation.
 */

#include "ImGuiOverlay.h"
#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"

#include <android/log.h>
#include <chrono>

#define LOG_TAG "ImGuiOverlay"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static double GetTimestamp() {
    using namespace std::chrono;
    return duration_cast<duration<double>>(steady_clock::now().time_since_epoch()).count();
}

ImGuiOverlay::ImGuiOverlay() = default;

ImGuiOverlay::~ImGuiOverlay() {
    Shutdown();
}

bool ImGuiOverlay::Init(ANativeWindow* window, int width, int height, ToggleBlockFn callback) {
    m_Window = window;
    m_Width = width;
    m_Height = height;
    m_ToggleBlockCallback = callback;

    // 1. Initialize EGL
    m_Display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (m_Display == EGL_NO_DISPLAY) return false;

    if (!eglInitialize(m_Display, nullptr, nullptr)) return false;

    const EGLint attribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 16,
        EGL_NONE
    };

    EGLConfig config;
    EGLint numConfigs;
    eglChooseConfig(m_Display, attribs, &config, 1, &numConfigs);

    const EGLint contextAttribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 3,
        EGL_NONE
    };

    m_Context = eglCreateContext(m_Display, config, EGL_NO_CONTEXT, contextAttribs);
    m_Surface = eglCreateWindowSurface(m_Display, config, m_Window, nullptr);

    if (!eglMakeCurrent(m_Display, m_Surface, m_Surface, m_Context)) {
        LOGE("eglMakeCurrent failed!");
        return false;
    }

    // 2. Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(static_cast<float>(width), static_cast<float>(height));
    io.IniFilename = nullptr; // Stateless in-memory for floating HUD

    // 3. Apply Strict Monochrome High-Contrast Black & White Theme
    SetupStrictMonochromeTheme();

    // 4. Initialize Platform/Renderer backends
    ImGui_ImplAndroid_Init(m_Window);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    m_LastFrameTime = GetTimestamp();
    m_Initialized = true;
    LOGI("Dear ImGui initialized with Strict Monochrome Theme.");
    return true;
}

/**
 * Strict Monochrome Theme Configuration:
 * Zero rounding (sharp rectangular borders), pitch black backgrounds (#000000 / #0D0D0D),
 * pure white text (#FFFFFF), crisp 1px borders, and removal of all default colored accents.
 */
void ImGuiOverlay::SetupStrictMonochromeTheme() {
    ImGuiStyle& style = ImGui::GetStyle();

    // Sharp geometry - ZERO rounding for structural brutalist technical look
    style.WindowRounding = 0.0f;
    style.ChildRounding = 0.0f;
    style.FrameRounding = 0.0f;
    style.PopupRounding = 0.0f;
    style.ScrollbarRounding = 0.0f;
    style.GrabRounding = 0.0f;
    style.TabRounding = 0.0f;

    // High contrast crisp borders
    style.WindowBorderSize = 1.0f;
    style.FrameBorderSize = 1.0f;
    style.PopupBorderSize = 1.0f;
    style.ItemSpacing = ImVec2(8.0f, 6.0f);
    style.FramePadding = ImVec2(6.0f, 4.0f);

    ImVec4* colors = style.Colors;

    // Pure black & dark structural base
    colors[ImGuiCol_Text]                  = ImVec4(1.00f, 1.00f, 1.00f, 1.00f); // Pure White Text
    colors[ImGuiCol_TextDisabled]          = ImVec4(0.55f, 0.55f, 0.55f, 1.00f); // Mid Gray
    colors[ImGuiCol_WindowBg]              = ImVec4(0.00f, 0.00f, 0.00f, 0.94f); // Pure Black 94% Alpha
    colors[ImGuiCol_ChildBg]               = ImVec4(0.06f, 0.06f, 0.06f, 1.00f); // Charcoal
    colors[ImGuiCol_PopupBg]               = ImVec4(0.02f, 0.02f, 0.02f, 1.00f);
    colors[ImGuiCol_Border]                = ImVec4(1.00f, 1.00f, 1.00f, 0.85f); // Sharp White Border
    colors[ImGuiCol_BorderShadow]          = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);

    // Header & Title bar
    colors[ImGuiCol_TitleBg]               = ImVec4(0.08f, 0.08f, 0.08f, 1.00f);
    colors[ImGuiCol_TitleBgActive]         = ImVec4(0.16f, 0.16f, 0.16f, 1.00f);
    colors[ImGuiCol_TitleBgCollapsed]      = ImVec4(0.00f, 0.00f, 0.00f, 0.80f);

    // Frames & Input fields
    colors[ImGuiCol_FrameBg]               = ImVec4(0.12f, 0.12f, 0.12f, 1.00f);
    colors[ImGuiCol_FrameBgHovered]        = ImVec4(0.22f, 0.22f, 0.22f, 1.00f);
    colors[ImGuiCol_FrameBgActive]         = ImVec4(0.30f, 0.30f, 0.30f, 1.00f);

    // Buttons: Monochrome High-Contrast
    colors[ImGuiCol_Button]                = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
    colors[ImGuiCol_ButtonHovered]         = ImVec4(0.32f, 0.32f, 0.32f, 1.00f);
    colors[ImGuiCol_ButtonActive]          = ImVec4(1.00f, 1.00f, 1.00f, 1.00f); // Inverts to white on click

    // Tabs
    colors[ImGuiCol_Tab]                   = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
    colors[ImGuiCol_TabHovered]            = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
    colors[ImGuiCol_TabActive]             = ImVec4(0.95f, 0.95f, 0.95f, 1.00f); // White active tab
    colors[ImGuiCol_TabUnfocused]          = ImVec4(0.08f, 0.08f, 0.08f, 1.00f);
    colors[ImGuiCol_TabUnfocusedActive]   = ImVec4(0.18f, 0.18f, 0.18f, 1.00f);

    // Scrollbars & Sliders
    colors[ImGuiCol_ScrollbarBg]           = ImVec4(0.02f, 0.02f, 0.02f, 0.50f);
    colors[ImGuiCol_ScrollbarGrab]         = ImVec4(0.40f, 0.40f, 0.40f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabHovered]  = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabActive]   = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    colors[ImGuiCol_CheckMark]             = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    colors[ImGuiCol_SliderGrab]            = ImVec4(0.85f, 0.85f, 0.85f, 1.00f);
    colors[ImGuiCol_SliderGrabActive]      = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    colors[ImGuiCol_Header]                = ImVec4(0.20f, 0.20f, 0.20f, 1.00f);
    colors[ImGuiCol_HeaderHovered]         = ImVec4(0.35f, 0.35f, 0.35f, 1.00f);
    colors[ImGuiCol_HeaderActive]          = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
}

void ImGuiOverlay::Resize(int width, int height) {
    m_Width = width;
    m_Height = height;
    if (m_Initialized) {
        ImGuiIO& io = ImGui::GetIO();
        io.DisplaySize = ImVec2(static_cast<float>(width), static_cast<float>(height));
    }
}

void ImGuiOverlay::HandleTouch(int action, float x, float y) {
    ImGuiIO& io = ImGui::GetIO();
    io.AddMousePosEvent(x, y);

    // Action 0 = ACTION_DOWN, 1 = ACTION_UP, 2 = ACTION_MOVE
    if (action == 0) {
        io.AddMouseButtonEvent(0, true);
    } else if (action == 1) {
        io.AddMouseButtonEvent(0, false);
    }
}

void ImGuiOverlay::RecordPacket(const std::string& srcIp, int srcPort,
                                const std::string& dstIp, int dstPort,
                                const std::string& proto, int bytes, bool blocked) {
    std::lock_guard<std::mutex> lock(m_DataMutex);
    m_TotalPacketsCaptured++;

    std::string key = dstIp + ":" + std::to_string(dstPort) + "[" + proto + "]";
    auto& conn = m_Connections[key];
    conn.srcIp = srcIp;
    conn.srcPort = srcPort;
    conn.dstIp = dstIp;
    conn.dstPort = dstPort;
    conn.protocol = proto;
    conn.totalPackets++;
    conn.totalBytes += bytes;
    conn.lastActiveSeconds = GetTimestamp();
    conn.isBlocked = blocked;
}

void ImGuiOverlay::RecordDroppedPacket(const std::string& ip, int port, const std::string& proto, int bytes) {
    std::lock_guard<std::mutex> lock(m_DataMutex);
    m_TotalPacketsDropped++;

    std::string key = ip + ":" + std::to_string(port) + "[" + proto + "]";
    if (m_Connections.count(key)) {
        m_Connections[key].isBlocked = true;
    }
}

void ImGuiOverlay::Render() {
    if (!m_Initialized) return;

    double now = GetTimestamp();
    double dt = now - m_LastFrameTime;
    m_LastFrameTime = now;
    if (dt > 0.0) {
        m_Fps = static_cast<float>(0.9 * m_Fps + 0.1 * (1.0 / dt));
    }

    // Start ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();

    // Render Floating Debugger Window
    RenderMainGui();

    // Render & EGL Buffer Swap
    ImGui::Render();
    glViewport(0, 0, m_Width, m_Height);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // Transparent background for overlay passthrough
    glClear(GL_COLOR_BUFFER_BIT);

    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(m_Display, m_Surface);
}

void ImGuiOverlay::RenderMainGui() {
    ImGui::SetNextWindowSize(ImVec2(780, 520), ImGuiCond_FirstUseEver);

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse |
                             ImGuiWindowFlags_NoScrollbar |
                             ImGuiWindowFlags_MenuBar;

    if (ImGui::Begin("[#] FLOATING GAME DEBUGGER - LIVE TRAFFIC MONITOR", nullptr, flags)) {
        // Menu Bar
        if (ImGui::BeginMenuBar()) {
            ImGui::Text("FPS: %.1f | CAPTURED: %lld | DROPPED: %lld",
                        m_Fps, m_TotalPacketsCaptured, m_TotalPacketsDropped);
            ImGui::EndMenuBar();
        }

        // Tabs
        if (ImGui::BeginTabBar("MainDebugTabBar", ImGuiTabBarFlags_None)) {
            if (ImGui::BeginTabItem("LIVE CONNECTIONS (IP CHECKER)")) {
                RenderConnectionMonitorTab();
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("BLOCKED ROUTES & DROP TEST")) {
                RenderBlockedIpTab();
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("JNI & KERNEL TUN STATS")) {
                RenderJniMetricsTab();
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }

        // MANDATORY STRICT MONOCHROME FOOTER
        ImGui::Dummy(ImVec2(0.0f, 8.0f));
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::TextDisabled("STATUS: ACTIVE | ENGINE: DEAR IMGUI (C++ NDK) | THEME: MONOCHROME");
        ImGui::SameLine(ImGui::GetWindowWidth() - 210.0f);
        ImGui::Text("Developer: Doni Andira");
    }
    ImGui::End();
}

void ImGuiOverlay::RenderConnectionMonitorTab() {
    ImGui::Text("OUTGOING GAME CONNECTIONS (TCP / UDP):");
    ImGui::Separator();

    static ImGuiTableFlags tableFlags = ImGuiTableFlags_Borders |
                                        ImGuiTableFlags_RowBg |
                                        ImGuiTableFlags_ScrollY |
                                        ImGuiTableFlags_SizingFixedFit;

    if (ImGui::BeginTable("ConnectionTable", 6, tableFlags, ImVec2(0, 320))) {
        ImGui::TableSetupColumn("DESTINATION IP", ImGuiTableColumnFlags_WidthStretch);
        ImGui::TableSetupColumn("PORT", ImGuiTableColumnFlags_WidthFixed, 60.0f);
        ImGui::TableSetupColumn("PROTO", ImGuiTableColumnFlags_WidthFixed, 55.0f);
        ImGui::TableSetupColumn("PACKETS", ImGuiTableColumnFlags_WidthFixed, 80.0f);
        ImGui::TableSetupColumn("BYTES", ImGuiTableColumnFlags_WidthFixed, 80.0f);
        ImGui::TableSetupColumn("ACTION", ImGuiTableColumnFlags_WidthFixed, 100.0f);
        ImGui::TableHeadersRow();

        std::lock_guard<std::mutex> lock(m_DataMutex);
        int idx = 0;
        for (auto& pair : m_Connections) {
            auto& conn = pair.second;
            ImGui::TableNextRow();

            // Highlight if blocked
            if (conn.isBlocked) {
                ImGui::TableSetBgColor(ImGuiTableBgTarget_RowBg0, IM_COL32(50, 50, 50, 255));
            }

            ImGui::TableSetColumnIndex(0);
            ImGui::Text("%s", conn.dstIp.c_str());

            ImGui::TableSetColumnIndex(1);
            ImGui::Text("%d", conn.dstPort);

            ImGui::TableSetColumnIndex(2);
            ImGui::Text("%s", conn.protocol.c_str());

            ImGui::TableSetColumnIndex(3);
            ImGui::Text("%lld", conn.totalPackets);

            ImGui::TableSetColumnIndex(4);
            ImGui::Text("%.1f KB", conn.totalBytes / 1024.0f);

            ImGui::TableSetColumnIndex(5);
            ImGui::PushID(idx++);
            if (conn.isBlocked) {
                if (ImGui::Button("[ UNBLOCK ]")) {
                    conn.isBlocked = false;
                    if (m_ToggleBlockCallback) m_ToggleBlockCallback(conn.dstIp, false);
                }
            } else {
                if (ImGui::Button("[ BLOCK ]")) {
                    conn.isBlocked = true;
                    if (m_ToggleBlockCallback) m_ToggleBlockCallback(conn.dstIp, true);
                }
            }
            ImGui::PopID();
        }
        ImGui::EndTable();
    }
}

void ImGuiOverlay::RenderBlockedIpTab() {
    ImGui::Text("ACTIVE IP BLACKLIST (FAULT INJECTION - DROP TESTING):");
    ImGui::TextDisabled("Dropped packets simulate sudden connection loss to test game resilience.");
    ImGui::Separator();

    std::lock_guard<std::mutex> lock(m_DataMutex);
    int blockedCount = 0;
    for (auto& pair : m_Connections) {
        if (pair.second.isBlocked) {
            blockedCount++;
            ImGui::BulletText("IP: %s | Port: %d [%s] -> DROPPING ALL ROUTED FRAMES",
                              pair.second.dstIp.c_str(), pair.second.dstPort, pair.second.protocol.c_str());
            ImGui::SameLine();
            ImGui::PushID(pair.first.c_str());
            if (ImGui::SmallButton("RESTORE")) {
                pair.second.isBlocked = false;
                if (m_ToggleBlockCallback) m_ToggleBlockCallback(pair.second.dstIp, false);
            }
            ImGui::PopID();
        }
    }

    if (blockedCount == 0) {
        ImGui::TextDisabled("No active IP routes blocked. Click '[ BLOCK ]' in the Live Connections tab.");
    }
}

void ImGuiOverlay::RenderJniMetricsTab() {
    ImGui::Text("KERNEL TUN & JNI BRIDGE TELEMETRY:");
    ImGui::Separator();
    ImGui::BulletText("Linux TUN Interface: tun0 / 10.1.1.2");
    ImGui::BulletText("Packet Interception Engine: VpnService IPv4 Parser");
    ImGui::BulletText("JNI Buffer Throughput: Zero-Copy RingBuffer");
    ImGui::BulletText("Total Raw Packets Intercepted: %lld", m_TotalPacketsCaptured);
    ImGui::BulletText("Packets Filtered / Dropped: %lld", m_TotalPacketsDropped);
    ImGui::BulletText("Overlay Surface: ANativeWindow (OpenGL ES 3.0 Context)");
}

void ImGuiOverlay::Shutdown() {
    if (!m_Initialized) return;

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();

    if (m_Display != EGL_NO_DISPLAY) {
        eglMakeCurrent(m_Display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (m_Surface != EGL_NO_SURFACE) eglDestroySurface(m_Display, m_Surface);
        if (m_Context != EGL_NO_CONTEXT) eglDestroyContext(m_Display, m_Context);
        eglTerminate(m_Display);
    }

    m_Display = EGL_NO_DISPLAY;
    m_Surface = EGL_NO_SURFACE;
    m_Context = EGL_NO_CONTEXT;
    m_Initialized = false;
    LOGI("ImGuiOverlay shutdown completed.");
}
