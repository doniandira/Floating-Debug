/**
 * ImGuiOverlay.h
 * High-performance Dear ImGui renderer on Android ANativeWindow via EGL / OpenGL ES 3.0.
 */

#pragma once

#include <android/native_window.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <string>
#include <unordered_map>
#include <vector>
#include <mutex>
#include <functional>

struct ConnectionMetric {
    std::string srcIp;
    int srcPort;
    std::string dstIp;
    int dstPort;
    std::string protocol;
    long long totalPackets = 0;
    long long totalBytes = 0;
    double lastActiveSeconds = 0.0;
    bool isBlocked = false;
    float currentKbps = 0.0f;
};

using ToggleBlockFn = std::function<void(const std::string&, bool)>;

class ImGuiOverlay {
public:
    ImGuiOverlay();
    ~ImGuiOverlay();

    bool Init(ANativeWindow* window, int width, int height, ToggleBlockFn callback);
    void Resize(int width, int height);
    void Render();
    void Shutdown();

    void HandleTouch(int action, float x, float y);
    void RecordPacket(const std::string& srcIp, int srcPort,
                      const std::string& dstIp, int dstPort,
                      const std::string& proto, int bytes, bool blocked);
    void RecordDroppedPacket(const std::string& ip, int port, const std::string& proto, int bytes);

private:
    void SetupStrictMonochromeTheme();
    void RenderMainGui();
    void RenderConnectionMonitorTab();
    void RenderBlockedIpTab();
    void RenderJniMetricsTab();

    // EGL State
    ANativeWindow* m_Window = nullptr;
    EGLDisplay m_Display = EGL_NO_DISPLAY;
    EGLSurface m_Surface = EGL_NO_SURFACE;
    EGLContext m_Context = EGL_NO_CONTEXT;
    int m_Width = 0;
    int m_Height = 0;
    bool m_Initialized = false;

    ToggleBlockFn m_ToggleBlockCallback;

    // Concurrency protected connection tracking
    std::mutex m_DataMutex;
    std::unordered_map<std::string, ConnectionMetric> m_Connections;
    long long m_TotalPacketsCaptured = 0;
    long long m_TotalPacketsDropped = 0;
    double m_LastFrameTime = 0.0;
    float m_Fps = 60.0f;
};