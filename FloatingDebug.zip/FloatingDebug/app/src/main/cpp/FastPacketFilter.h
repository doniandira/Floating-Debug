/**
 * FastPacketFilter.h
 * High-Frequency Zero-Copy Packet Engine for Android NDK.
 * Eliminates Dalvik/ART GC pauses, JNI roundtrip stalls, and frame drops.
 */

#pragma once

#include <cstdint>
#include <atomic>
#include <vector>
#include <array>
#include <string>
#include <functional>
#include <thread>

// Aligned IPv4 Header structure for single-cycle bitwise access
struct alignas(4) FastIPv4Header {
    uint8_t  version_ihl;      // Version (4b) + IHL (4b)
    uint8_t  tos;              // Type of Service
    uint16_t total_length;     // Total Packet Length (Network Byte Order)
    uint16_t id;               // Identification
    uint16_t flags_fragment;   // Fragment Offset
    uint8_t  ttl;              // Time To Live
    uint8_t  protocol;         // Protocol (6 = TCP, 17 = UDP)
    uint16_t checksum;         // Header Checksum
    uint32_t src_ip;           // Source IP (32-bit Integer)
    uint32_t dst_ip;           // Destination IP (32-bit Integer)
};

// Aligned UDP Header (8 bytes)
struct alignas(4) FastUDPHeader {
    uint16_t src_port;         // Source Port
    uint16_t dst_port;         // Destination Port
    uint16_t length;           // UDP Length
    uint16_t checksum;         // UDP Checksum
};

// Ring buffer entry for batching telemetry to ImGui
struct alignas(32) PacketTelemetryEntry {
    uint32_t dst_ip;
    uint16_t dst_port;
    uint8_t  protocol;         // 17 = UDP, 6 = TCP
    uint8_t  is_blocked;       // 1 if dropped, 0 if passed
    uint32_t packet_size;
    uint64_t timestamp_ns;
};

class FastPacketFilter {
public:
    static constexpr size_t MAX_BLOCKED_IPS = 128;
    static constexpr size_t TELEMETRY_RING_SIZE = 16384;
    static constexpr size_t BUFFER_SIZE = 32768;

    FastPacketFilter();
    ~FastPacketFilter();

    // Start background native worker on raw TUN file descriptor
    bool StartWorker(int tunFd);
    void StopWorker();

    // Lock-free atomic IP blocklist operations (O(1) lookups in hot path)
    void BlockIp(uint32_t ipNetworkOrder);
    void UnblockIp(uint32_t ipNetworkOrder);
    void BlockIpString(const std::string& ipStr);
    void UnblockIpString(const std::string& ipStr);
    bool IsIpBlocked(uint32_t ipNetworkOrder) const;

    // Telemetry retrieval for Dear ImGui (drained each frame)
    size_t DrainTelemetry(PacketTelemetryEntry* outBuffer, size_t maxCount);

    // Atomic High-Frequency Counters
    uint64_t GetTotalPacketsProcessed() const { return m_TotalPackets.load(std::memory_order_relaxed); }
    uint64_t GetTotalPacketsDropped() const { return m_TotalDropped.load(std::memory_order_relaxed); }
    uint64_t GetUdpPacketsProcessed() const { return m_UdpPackets.load(std::memory_order_relaxed); }

private:
    void WorkerLoop();
    void PushTelemetry(uint32_t dstIp, uint16_t dstPort, uint8_t proto, uint32_t size, bool blocked);

    int m_TunFd = -1;
    std::atomic<bool> m_Running{false};
    std::thread m_WorkerThread;

    // Lock-free Blocklist: Array of atomic 32-bit integer IPs
    // In network byte order. 0 means empty slot.
    std::array<std::atomic<uint32_t>, MAX_BLOCKED_IPS> m_BlockedIps{};

    // Atomic telemetry ring buffer
    std::array<PacketTelemetryEntry, TELEMETRY_RING_SIZE> m_TelemetryRing{};
    std::atomic<size_t> m_RingWriteHead{0};
    size_t m_RingReadHead{0};

    // Performance metrics
    std::atomic<uint64_t> m_TotalPackets{0};
    std::atomic<uint64_t> m_TotalDropped{0};
    std::atomic<uint64_t> m_UdpPackets{0};
};
