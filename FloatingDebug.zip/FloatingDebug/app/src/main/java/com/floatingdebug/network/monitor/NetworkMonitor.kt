package com.floatingdebug.network.monitor

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Penampung statistik koneksi yang diisi oleh VPN service dan dibaca oleh overlay.
 * Data dikelompokkan per IP tujuan agar mudah dipilih untuk diblokir.
 */
object NetworkMonitor {

    data class ConnStat(
        val ip: String,
        val port: Int,
        val protocol: String,
        val packets: Long,
        val bytes: Long,
        val lastSeenMs: Long
    )

    private class Entry(val ip: String) {
        var lastPort = 0
        var lastProto = ""
        var packets = 0L
        var bytes = 0L
        var lastSeen = 0L
    }

    private const val MAX_ENTRIES = 300

    private val entries = ConcurrentHashMap<String, Entry>()

    val totalPackets = AtomicLong(0)
    val totalBytes = AtomicLong(0)
    val totalDropped = AtomicLong(0)

    /** Dicatat untuk setiap paket yang diteruskan. */
    fun record(dstIp: String, dstPort: Int, protocol: String, size: Int) {
        totalPackets.incrementAndGet()
        totalBytes.addAndGet(size.toLong())

        val entry = entries.getOrPut(dstIp) { Entry(dstIp) }
        synchronized(entry) {
            entry.lastPort = dstPort
            entry.lastProto = protocol
            entry.packets += 1
            entry.bytes += size.toLong()
            entry.lastSeen = System.currentTimeMillis()
        }
        if (entries.size > MAX_ENTRIES) trim()
    }

    /** Dicatat untuk setiap paket yang dijatuhkan karena IP-nya diblokir. */
    fun recordDropped(@Suppress("UNUSED_PARAMETER") size: Int) {
        totalDropped.incrementAndGet()
    }

    /** Daftar IP dengan trafik terbesar (paling banyak data lebih dulu). */
    fun snapshot(limit: Int): List<ConnStat> {
        return entries.values
            .map { e ->
                synchronized(e) {
                    ConnStat(e.ip, e.lastPort, e.lastProto, e.packets, e.bytes, e.lastSeen)
                }
            }
            .sortedByDescending { it.bytes }
            .take(limit)
    }

    fun reset() {
        entries.clear()
        totalPackets.set(0)
        totalBytes.set(0)
        totalDropped.set(0)
    }

    /** Buang entri yang paling lama tidak aktif agar memori tidak membengkak. */
    private fun trim() {
        val oldest = entries.values
            .sortedBy { it.lastSeen }
            .take(entries.size - (MAX_ENTRIES * 8 / 10))
        for (e in oldest) entries.remove(e.ip)
    }
}
