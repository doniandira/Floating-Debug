package com.floatingdebug.network.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.*
import com.floatingdebug.network.jni.NativeBridge

/**
 * FloatingOverlayService:
 * Manages the SYSTEM_ALERT_WINDOW floating overlay that sits permanently
 * on top of running games without crashing or causing input traps.
 */
class FloatingOverlayService : Service(), SurfaceHolder.Callback {

    companion object {
        private const val TAG = "FloatingOverlayService"
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var surfaceView: SurfaceView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    // Window position drag tracking
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setupFloatingView()
    }

    private fun setupFloatingView() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // Layout parameters:
        // FLAG_NOT_TOUCH_MODAL: Allows touches outside ImGui to pass through to the game
        // FLAG_WATCH_OUTSIDE_TOUCH: Detect touches outside
        // PixelFormat.TRANSLUCENT: Seamless transparent backdrop for Dear ImGui
        layoutParams = WindowManager.LayoutParams(
            820, // Window width in pixels
            640, // Window height in pixels
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 120
        }

        surfaceView = SurfaceView(this).apply {
            setZOrderOnTop(true)
            holder.setFormat(PixelFormat.TRANSLUCENT)
            holder.addCallback(this@FloatingOverlayService)
        }

        // Forward Android touch events into Dear ImGui IO
        surfaceView?.setOnTouchListener { _, event ->
            val action = event.actionMasked
            val x = event.x
            val y = event.y

            // Send touch event down to C++ ImGui_ImplAndroid
            NativeBridge.onTouchEvent(action, x, y)
            true
        }

        windowManager?.addView(surfaceView, layoutParams)
        Log.i(TAG, "Floating Overlay View added to WindowManager")
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        Log.i(TAG, "Surface created. Initializing EGL and Dear ImGui native context...")
        NativeBridge.initImGui(holder.surface, surfaceView?.width ?: 800, surfaceView?.height ?: 600)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        NativeBridge.onSurfaceChanged(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        Log.i(TAG, "Surface destroyed. Tearing down EGL and ImGui...")
        NativeBridge.destroyImGui()
    }

    override fun onDestroy() {
        if (surfaceView != null) {
            windowManager?.removeView(surfaceView)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}