package com.floatingdebug.network.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.floatingdebug.network.monitor.NetworkMonitor
import kotlin.math.abs

/**
 * Overlay melayang berbasis View Android biasa (tanpa ImGui / OpenGL).
 *
 * - Berupa gelembung "FD" yang bisa digeser; ketuk untuk membuka panel.
 * - Panel menampilkan statistik, daftar koneksi teratas dengan tombol BLOKIR/LEPAS,
 *   dan daftar IP yang sedang diblokir.
 * - Sentuhan di luar overlay diteruskan ke aplikasi/game di bawahnya.
 */
class FloatingOverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "floating_overlay_channel"
        private const val NOTIFICATION_ID = 1002
        private const val REFRESH_MS = 1000L
        private const val TOUCH_PAUSE_MS = 700L

        @Volatile
        var isRunning: Boolean = false
    }

    private var windowManager: WindowManager? = null
    private var rootView: FrameLayout? = null
    private var params: WindowManager.LayoutParams? = null

    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var statsText: TextView? = null
    private var hintText: TextView? = null
    private var listContainer: LinearLayout? = null

    private val handler = Handler(Looper.getMainLooper())
    private var lastTouchMs = 0L

    private val refreshRunnable = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, REFRESH_MS)
        }
    }

    // ---------------------------------------------------------------- siklus hidup

    override fun onCreate() {
        super.onCreate()
        // Harus segera menjadi foreground service agar tidak dimatikan sistem
        startAsForeground()

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin overlay belum diberikan", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildOverlay()
        isRunning = true
        handler.post(refreshRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(refreshRunnable)
        val view = rootView
        if (view != null) {
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                // View mungkin sudah dilepas
            }
        }
        rootView = null
        isRunning = false
        super.onDestroy()
    }

    private fun startAsForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Overlay Floating Debug",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Floating Debug")
            .setContentText("Overlay aktif. Buka aplikasi untuk menghentikan.")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    // ---------------------------------------------------------------- membangun tampilan

    private fun buildOverlay() {
        val root = object : FrameLayout(this) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                lastTouchMs = SystemClock.uptimeMillis()
                return super.dispatchTouchEvent(ev)
            }
        }

        // --- Gelembung (keadaan tertutup) ---
        val bubbleSize = dp(52)
        val bubbleView = TextView(this).apply {
            text = "FD"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xF0101010.toInt())
                setStroke(dp(2), Color.WHITE)
            }
            layoutParams = FrameLayout.LayoutParams(bubbleSize, bubbleSize)
        }

        // --- Panel (keadaan terbuka) ---
        val panelView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(14).toFloat()
                setColor(0xF2101010.toInt())
                setStroke(dp(1), 0x66FFFFFF)
            }
            layoutParams = FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT)
            visibility = View.GONE
        }

        // Baris judul (juga berfungsi sebagai pegangan untuk menggeser)
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "FLOATING DEBUG"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val minimizeButton = headerButton("\u2014") { showPanel(false) }
        val closeButton = headerButton("X") { stopSelf() }
        titleRow.addView(title)
        titleRow.addView(minimizeButton)
        titleRow.addView(closeButton)
        panelView.addView(titleRow)

        val stats = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(8), 0, 0)
        }
        val hint = TextView(this).apply {
            setTextColor(0xFF9A9A9A.toInt())
            textSize = 10f
            setPadding(0, dp(2), 0, dp(6))
        }
        panelView.addView(stats)
        panelView.addView(hint)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            addView(list)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(230)
            )
        }
        panelView.addView(scroll)

        val resetButton = TextView(this).apply {
            text = "RESET STATISTIK"
            setTextColor(Color.WHITE)
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = outline(dp(8))
            setOnClickListener {
                NetworkMonitor.reset()
                refresh(force = true)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        panelView.addView(resetButton)

        root.addView(bubbleView)
        root.addView(panelView)

        val layoutParams = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(140)
        }

        rootView = root
        params = layoutParams
        bubble = bubbleView
        panel = panelView
        statsText = stats
        hintText = hint
        listContainer = list

        attachDrag(bubbleView) { showPanel(true) }
        attachDrag(title, null)

        windowManager?.addView(root, layoutParams)
    }

    private fun showPanel(expanded: Boolean) {
        panel?.visibility = if (expanded) View.VISIBLE else View.GONE
        bubble?.visibility = if (expanded) View.GONE else View.VISIBLE
        if (expanded) refresh(force = true)
    }

    // ---------------------------------------------------------------- menggeser

    /** Membuat [handle] bisa digeser; jika hanya diketuk (tanpa geser) menjalankan [onClick]. */
    private fun attachDrag(handle: View, onClick: (() -> Unit)?) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        handle.setOnTouchListener { _, event ->
            val p = params ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x
                    startY = p.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        p.x = startX + dx
                        p.y = startY + dy
                        val view = rootView
                        if (view != null) windowManager?.updateViewLayout(view, p)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    // ---------------------------------------------------------------- isi panel

    private fun refresh(force: Boolean = false) {
        if (panel?.visibility != View.VISIBLE) return

        val packets = NetworkMonitor.totalPackets.get()
        val bytes = NetworkMonitor.totalBytes.get()
        val dropped = NetworkMonitor.totalDropped.get()
        statsText?.text = "Paket $packets | ${formatBytes(bytes)} | Drop $dropped"
        hintText?.text = if (GameDebugVpnService.isActive) {
            "VPN aktif. Ketuk BLOKIR untuk menjatuhkan paket ke IP itu."
        } else {
            "VPN belum aktif. Mulai \"VPN MONITOR\" di aplikasi agar daftar terisi."
        }

        // Jangan membangun ulang daftar saat jari sedang menyentuh (agar ketukan tidak hilang)
        if (!force && SystemClock.uptimeMillis() - lastTouchMs < TOUCH_PAUSE_MS) return
        rebuildList()
    }

    private fun rebuildList() {
        val container = listContainer ?: return
        container.removeAllViews()

        val blocked = GameDebugVpnService.blockedIps

        if (blocked.isNotEmpty()) {
            container.addView(sectionLabel("DIBLOKIR (${blocked.size})"))
            for ((ip, dropCount) in blocked) {
                container.addView(connectionRow(ip, "dijatuhkan: $dropCount paket", true))
            }
        }

        container.addView(sectionLabel("KONEKSI TERATAS"))
        val connections = NetworkMonitor.snapshot(15).filter { !blocked.containsKey(it.ip) }
        if (connections.isEmpty()) {
            container.addView(
                TextView(this).apply {
                    text = "Belum ada koneksi tercatat."
                    setTextColor(0xFF7A7A7A.toInt())
                    textSize = 10.5f
                    setPadding(0, dp(4), 0, dp(4))
                }
            )
        } else {
            for (c in connections) {
                val detail = "${c.protocol}:${c.port} | ${c.packets} pkt | ${formatBytes(c.bytes)}"
                container.addView(connectionRow(c.ip, detail, false))
            }
        }
    }

    private fun connectionRow(ip: String, detail: String, isBlocked: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(
            TextView(this).apply {
                text = ip
                setTextColor(Color.WHITE)
                textSize = 12f
                typeface = Typeface.MONOSPACE
            }
        )
        texts.addView(
            TextView(this).apply {
                text = detail
                setTextColor(0xFF9A9A9A.toInt())
                textSize = 9.5f
            }
        )
        val action = TextView(this).apply {
            text = if (isBlocked) "LEPAS" else "BLOKIR"
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7))
            if (isBlocked) {
                setTextColor(Color.WHITE)
                background = outline(dp(6))
            } else {
                setTextColor(Color.BLACK)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(6).toFloat()
                    setColor(Color.WHITE)
                }
            }
            setOnClickListener {
                if (isBlocked) GameDebugVpnService.unblockIp(ip) else GameDebugVpnService.blockIp(ip)
                refresh(force = true)
            }
        }
        row.addView(texts)
        row.addView(action)
        return row
    }

    private fun sectionLabel(text: String): TextView =
        TextView(this).apply {
            this.text = text
            setTextColor(0xFFBDBDBD.toInt())
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(2))
        }

    private fun headerButton(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener { onClick() }
        }

    private fun outline(radiusPx: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), 0x99FFFFFF.toInt())
        }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format("%.1f KB", bytes / 1024.0)
        else -> String.format("%.2f MB", bytes / (1024.0 * 1024.0))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
