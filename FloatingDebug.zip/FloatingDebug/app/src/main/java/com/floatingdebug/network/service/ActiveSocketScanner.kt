package com.floatingdebug.network.service

import android.util.Log
import java.io.BufferedReader
import java.io.File
import java.io.FileReader

data class SocketEntry(
    val sl: String,
    val localIp: String,
    val localPort: Int,
    val remoteIp: String,
    val remotePort: Int,
    val state: String,
    val uid: Int,
    val inode: Long,
    val protocol: String
)

/**
 * ActiveSocketScanner:
 * Inspects Linux kernel procfs sockets (/proc/net/tcp, /proc/net/udp) to discover
 * which game server IPs are actively established by the foreground game app.
 */
object ActiveSocketScanner {

    private const val TAG = "ActiveSocketScanner"

    fun scanActiveSockets(): List<SocketEntry> {
        val sockets = mutableListOf<SocketEntry>()
        sockets.addAll(parseProcNetFile("/proc/net/tcp", "TCP"))
        sockets.addAll(parseProcNetFile("/proc/net/udp", "UDP"))
        return sockets
    }

    private fun parseProcNetFile(filePath: String, proto: String): List<SocketEntry> {
        val file = File(filePath)
        if (!file.exists() || !file.canRead()) return emptyList()

        val results = mutableListOf<SocketEntry>()
        try {
            BufferedReader(FileReader(file)).use { reader ->
                // Skip header line: "sl  local_address rem_address   st tx_queue rx_queue ..."
                var line = reader.readLine()
                while (reader.readLine().also { line = it } != null) {
                    val tokens = line!!.trim().split(Regex("\\s+"))
                    if (tokens.size < 10) continue

                    val sl = tokens[0].trimEnd(':')
                    val localAddr = tokens[1]
                    val remoteAddr = tokens[2]
                    val rawState = tokens[3]
                    val uid = tokens[7].toIntOrNull() ?: -1
                    val inode = tokens[9].toLongOrNull() ?: 0L

                    val (lIp, lPort) = parseHexAddress(localAddr)
                    val (rIp, rPort) = parseHexAddress(remoteAddr)

                    val stateStr = when (rawState) {
                        "01" -> "ESTABLISHED"
                        "02" -> "SYN_SENT"
                        "07" -> "CLOSE"
                        else -> "ACTIVE"
                    }

                    // Ignore loopback 127.0.0.1 or 0.0.0.0 listening sockets
                    if (rIp != "0.0.0.0" && !rIp.startsWith("127.")) {
                        results.add(
                            SocketEntry(
                                sl = sl,
                                localIp = lIp,
                                localPort = lPort,
                                remoteIp = rIp,
                                remotePort = rPort,
                                state = stateStr,
                                uid = uid,
                                inode = inode,
                                protocol = proto
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing $filePath", e)
        }
        return results
    }

    /**
     * Parses kernel hex address "0100007F:0050" -> ("127.0.0.1", 80)
     */
    private fun parseHexAddress(hex: String): Pair<String, Int> {
        val parts = hex.split(":")
        if (parts.size != 2) return Pair("0.0.0.0", 0)

        val ipHex = parts[0]
        val portHex = parts[1]

        val port = portHex.toIntOrNull(16) ?: 0

        // Kernel stores IP in little-endian hex: 2CBE10A2 -> 162.16.190.44
        return try {
            val b1 = ipHex.substring(6, 8).toInt(16)
            val b2 = ipHex.substring(4, 6).toInt(16)
            val b3 = ipHex.substring(2, 4).toInt(16)
            val b4 = ipHex.substring(0, 2).toInt(16)
            val ipStr = "$b1.$b2.$b3.$b4"
            Pair(ipStr, port)
        } catch (e: Exception) {
            Pair("0.0.0.0", port)
        }
    }
}