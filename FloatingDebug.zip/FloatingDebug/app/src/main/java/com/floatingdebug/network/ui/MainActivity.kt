package com.floatingdebug.network.ui

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.floatingdebug.network.BuildConfig
import com.floatingdebug.network.service.FloatingOverlayService
import com.floatingdebug.network.service.GameDebugVpnService
import com.floatingdebug.network.update.UpdateInfo
import com.floatingdebug.network.update.UpdateManager
import com.floatingdebug.network.update.UpdateResult
import java.io.File

/**
 * Layar utama: izin overlay, VPN monitor, tampilan overlay, dan pembaruan online.
 * Dibuat dengan View biasa (tanpa XML layout) agar sederhana.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var permissionText: TextView
    private lateinit var updateText: TextView
    private var pendingApk: File? = null

    private val vpnLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            startVpnService()
        } else {
            toast("Izin VPN ditolak")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        // Cek update otomatis saat aplikasi dibuka (diam jika tidak ada update)
        if (savedInstanceState == null) checkUpdate(silent = true)
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatus()
        // Lanjutkan pemasangan jika pengguna baru saja mengaktifkan izin "pasang aplikasi"
        val apk = pendingApk
        if (apk != null && UpdateManager.canInstall(this)) {
            pendingApk = null
            UpdateManager.install(this, apk)
        }
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi(): View {
        val pad = dp(18)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        column.addView(label("FLOATING DEBUG", 22f, Color.WHITE, bold = true))
        column.addView(label("Versi ${BuildConfig.VERSION_NAME}", 13f, 0xFFB0B0B0.toInt()))
        column.addView(space(14))

        permissionText = label("", 12f, 0xFFB0B0B0.toInt())
        column.addView(permissionText)
        column.addView(space(10))

        column.addView(actionButton("1. IZINKAN OVERLAY") { requestOverlayPermission() })
        column.addView(actionButton("2. MULAI VPN MONITOR") { startVpn() })
        column.addView(actionButton("3. TAMPILKAN OVERLAY") { showOverlay() })
        column.addView(actionButton("HENTIKAN SEMUA") { stopAll() })
        column.addView(space(10))
        column.addView(
            label(
                "Catatan: VPN pada versi ini belum meneruskan paket ke internet, sehingga " +
                    "koneksi HP terputus selama VPN aktif. Hentikan VPN setelah selesai menguji.",
                11f,
                0xFF8A8A8A.toInt()
            )
        )

        column.addView(space(18))
        column.addView(label("PEMBARUAN ONLINE", 12f, Color.WHITE, bold = true))
        updateText = label("Belum diperiksa.", 12f, 0xFFB0B0B0.toInt())
        column.addView(updateText)
        column.addView(space(6))
        column.addView(actionButton("CEK UPDATE") { checkUpdate(silent = false) })

        column.addView(space(18))
        column.addView(label("Developer: Doni Andira", 11f, 0xFF8A8A8A.toInt()))

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            addView(column)
        }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        return scroll
    }

    private fun refreshPermissionStatus() {
        val overlay = if (Settings.canDrawOverlays(this)) "diizinkan" else "belum diizinkan"
        permissionText.text = "Izin overlay: $overlay"
    }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun actionButton(text: String, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(Color.BLACK)
            backgroundTintList = ColorStateList.valueOf(Color.WHITE)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }

    private fun space(heightDp: Int): View =
        View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(heightDp)
            )
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- layanan

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            toast("Izin overlay sudah aktif")
            return
        }
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun startVpn() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) vpnLauncher.launch(prepare) else startVpnService()
    }

    private fun startVpnService() {
        val intent = Intent(this, GameDebugVpnService::class.java)
            .setAction(GameDebugVpnService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
        toast("VPN monitor dimulai")
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Izinkan overlay dulu")
            requestOverlayPermission()
            return
        }
        startService(Intent(this, FloatingOverlayService::class.java))
    }

    private fun stopAll() {
        stopService(Intent(this, FloatingOverlayService::class.java))
        startService(
            Intent(this, GameDebugVpnService::class.java)
                .setAction(GameDebugVpnService.ACTION_STOP)
        )
        toast("Layanan dihentikan")
    }

    // ---------------------------------------------------------------- update

    private fun checkUpdate(silent: Boolean) {
        if (!silent) updateText.text = "Memeriksa update..."
        UpdateManager.checkForUpdate { result ->
            if (isFinishing || isDestroyed) return@checkForUpdate
            when (result) {
                is UpdateResult.NotConfigured ->
                    updateText.text = "Update online belum diatur (alamat repositori tidak diketahui)."
                is UpdateResult.UpToDate -> {
                    updateText.text = "Sudah versi terbaru (v${BuildConfig.VERSION_NAME})."
                    if (!silent) toast("Sudah versi terbaru")
                }
                is UpdateResult.Error ->
                    updateText.text = "Gagal memeriksa update: ${result.message}"
                is UpdateResult.Available -> {
                    updateText.text = "Update tersedia: v${result.info.versionName}"
                    showUpdateDialog(result.info)
                }
            }
        }
    }

    private fun showUpdateDialog(info: UpdateInfo) {
        val sizeText = if (info.sizeBytes > 0) {
            " (" + String.format("%.1f", info.sizeBytes / 1048576.0) + " MB)"
        } else {
            ""
        }
        val notes = info.notes.trim().ifBlank { "Tidak ada catatan rilis." }.take(800)
        AlertDialog.Builder(this)
            .setTitle("Update tersedia: v${info.versionName}")
            .setMessage(
                "Versi terpasang: v${BuildConfig.VERSION_NAME}\n" +
                    "Ukuran unduhan$sizeText\n\n$notes"
            )
            .setPositiveButton("UPDATE SEKARANG") { _, _ -> startDownload(info) }
            .setNegativeButton("NANTI", null)
            .show()
    }

    private fun startDownload(info: UpdateInfo) {
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = false
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(24), dp(16), dp(24), dp(8))
            addView(
                bar,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Mengunduh v${info.versionName}...")
            .setView(box)
            .setCancelable(false)
            .create()
        dialog.show()

        UpdateManager.download(
            this,
            info,
            onProgress = { percent -> bar.progress = percent },
            onDone = { file, error ->
                dialog.dismiss()
                if (file == null) {
                    updateText.text = "Gagal mengunduh: ${error ?: "tidak diketahui"}"
                    toast("Gagal mengunduh update")
                } else {
                    installOrAskPermission(file)
                }
            }
        )
    }

    private fun installOrAskPermission(file: File) {
        if (UpdateManager.canInstall(this)) {
            UpdateManager.install(this, file)
            return
        }
        pendingApk = file
        AlertDialog.Builder(this)
            .setTitle("Izin pemasangan diperlukan")
            .setMessage(
                "Android perlu izin \"Pasang aplikasi tidak dikenal\" untuk aplikasi ini. " +
                    "Aktifkan izinnya, lalu kembali ke aplikasi. Pemasangan akan dilanjutkan otomatis."
            )
            .setPositiveButton("BUKA PENGATURAN") { _, _ ->
                UpdateManager.openInstallPermissionSettings(this)
            }
            .setNegativeButton("BATAL") { _, _ -> pendingApk = null }
            .show()
    }
}
