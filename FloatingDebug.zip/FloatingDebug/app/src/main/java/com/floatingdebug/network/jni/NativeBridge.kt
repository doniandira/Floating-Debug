package com.floatingdebug.network.jni

import android.view.Surface
import com.floatingdebug.network.service.GameDebugVpnService

/**
 * NativeBridge:
 * Kotlin-side JNI declarations mapping directly to C++ native-lib.cpp.
 */
object NativeBridge {

    init {
        System.loadLibrary("floating_imgui_debug")
    }

    // Lifecycle
    external fun initImGui(surface: Surface, width: Int, height: Int): Boolean
    external fun onSurfaceChanged(width: Int, height: Int)
    external fun renderFrame()
    external fun destroyImGui()

    // Touch & Input Forwarding
    external fun onTouchEvent(action: Int, x: Float, y: Float)

    // Telemetry & IP filter push
    external fun pushNetworkMetric(
        srcIp: String,
        srcPort: Int,
        dstIp: String,
        dstPort: Int,
        protocol: String,
        packetSize: Int,
        isBlocked: Boolean
    )

    external fun onPacketDropped(ip: String, port: Int, protocol: String, length: Int)

    /**
     * Called from C++ Dear ImGui when user clicks "BLOCK" or "UNBLOCK" button!
     */
    @JvmStatic
    fun toggleIpBlockFromNative(ip: String, shouldBlock: Boolean) {
        if (shouldBlock) {
            GameDebugVpnService.blockIp(ip)
        } else {
            GameDebugVpnService.unblockIp(ip)
        }
    }
}