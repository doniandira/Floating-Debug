package com.floatingdebug.network.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.floatingdebug.network.jni.NativeBridge
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * GameDebugVpnService:
 * Intercepts outgoing and incoming network packets at the IP layer via Linux TUN.
 * Performs dynamic packet dropping against blacklisted game server IPs for drop testing.
 */
class GameDebugVpnService : VpnService(), Runnable {

    companion object {
        private const val TAG = "GameDebugVpnService"
        const val ACTION_START = "com.floatingdebug.START_VPN"
        const val ACTION_STOP = "com.floatingdebug.STOP_VPN"
        const val CHANNEL_ID = "game_debug_vpn_channel"
        private const val NOTIFICATION_ID = 1001

        // Thread-safe map of blocked Destination IPs -> Drop Count
        val blockedIps = ConcurrentHashMap<String, Long>()

        fun blockIp(ip: String) {
            blockedIps.putIfAbsent(ip, 0L)
            Log.w(TAG, "[PACKET FILTER] Added IP to blocklist: $ip")
        }

        fun unblockIp(ip: String) {
            blockedIps.remove(ip)
            Log.i(TAG, "[PACKET FILTER] Removed IP from blocklist: $ip")
        }

        fun isIpBlocked(ip: String): Boolean = blockedIps.containsKey(ip)
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var vpnThread: Thread? = null
    private val isRunning = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startVpnEngine()
            ACTION_STOP -> stopVpnEngine()
        }
        return START_STICKY
    }

    private fun startVpnEngine() {
        if (isRunning.get()) return
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())

        try {
            // Configure local TUN interface (virtual loopback subnet)
            val builder = Builder()
                .setSession("GameDebugVpn")
                .addAddress("10.1.1.2", 32)
                .addRoute("0.0.0.0", 0) // Route all IPv4 traffic into our packet filter
                .setMtu(1500)
                .setBlocking(true)

            // Avoid trapping the debugging proxy itself
            // If you run an upstream forwarder, builder.addDisallowedApplication(packageName)
            builder.addDisallowedApplication(packageName)

            vpnInterface = builder.establish()
            isRunning.set(true)

            vpnThread = Thread(this, "GameDebugVpnWorkerThread").apply { start() }
            Log.i(TAG, "VPN Engine active. FileDescriptor: ${vpnInterface?.fd}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to establish VPN interface", e)
            stopSelf()
        }
    }

    override fun run() {
        val fd = vpnInterface?.fileDescriptor ?: return
        val inputStream = FileInputStream(fd)
        val outputStream = FileOutputStream(fd)
        val packetBuffer = ByteBuffer.allocate(32768)

        Log.i(TAG, "Packet filter worker running. Intercepting raw IP frames...")

        while (isRunning.get()) {
            try {
                packetBuffer.clear()
                val bytesRead = inputStream.read(packetBuffer.array())
                if (bytesRead <= 0) continue

                packetBuffer.limit(bytesRead)

                // Inspect IPv4 Header
                // Byte 0: Version (4 bits) + IHL (4 bits)
                val versionAndIhl = packetBuffer.get(0).toInt() and 0xFF
                val version = versionAndIhl shr 4
                if (version != 4) {
                    // Non-IPv4 pass-through (or drop IPv6 if testing IPv4 game server)
                    outputStream.write(packetBuffer.array(), 0, bytesRead)
                    continue
                }

                val ihl = (versionAndIhl and 0x0F) * 4
                val protocol = packetBuffer.get(9).toInt() and 0xFF // 6 = TCP, 17 = UDP

                // Extract Source IP (bytes 12-15) and Destination IP (bytes 16-19)
                val srcIpBytes = ByteArray(4)
                val dstIpBytes = ByteArray(4)
                System.arraycopy(packetBuffer.array(), 12, srcIpBytes, 0, 4)
                System.arraycopy(packetBuffer.array(), 16, dstIpBytes, 0, 4)

                val srcIp = InetAddress.getByAddress(srcIpBytes).hostAddress ?: ""
                val dstIp = InetAddress.getByAddress(dstIpBytes).hostAddress ?: ""

                // Extract ports
                var srcPort = 0
                var dstPort = 0
                if (protocol == 6 || protocol == 17) {
                    srcPort = ((packetBuffer.get(ihl).toInt() and 0xFF) shl 8) or
                              (packetBuffer.get(ihl + 1).toInt() and 0xFF)
                    dstPort = ((packetBuffer.get(ihl + 2).toInt() and 0xFF) shl 8) or
                              (packetBuffer.get(ihl + 3).toInt() and 0xFF)
                }

                val protoName = when (protocol) {
                    6 -> "TCP"
                    17 -> "UDP"
                    else -> "OTHER"
                }

                // ==========================================================
                // 1. DYNAMIC IP BLOCKING CHECK
                // ==========================================================
                if (blockedIps.containsKey(dstIp) || blockedIps.containsKey(srcIp)) {
                    val targetBlocked = if (blockedIps.containsKey(dstIp)) dstIp else srcIp
                    blockedIps.compute(targetBlocked) { _, count -> (count ?: 0L) + 1L }

                    // Log drop & Notify Native ImGui
                    NativeBridge.onPacketDropped(targetBlocked, dstPort, protoName, bytesRead)

                    // DROP: Intentionally do NOT write back to outputStream!
                    // This creates a silent blackhole / connection drop for the game client.
                    continue
                }

                // ==========================================================
                // 2. LIVE TELEMETRY BRIDGE TO C++ IMGUI
                // ==========================================================
                // Forward packet metadata to Native ImGui render buffer
                NativeBridge.pushNetworkMetric(
                    srcIp = srcIp,
                    srcPort = srcPort,
                    dstIp = dstIp,
                    dstPort = dstPort,
                    protocol = protoName,
                    packetSize = bytesRead,
                    isBlocked = false
                )

                // Forward allowed traffic
                outputStream.write(packetBuffer.array(), 0, bytesRead)

            } catch (e: Exception) {
                if (isRunning.get()) {
                    Log.e(TAG, "Error processing packet buffer", e)
                }
            }
        }
    }

    private fun stopVpnEngine() {
        isRunning.set(false)
        try {
            vpnInterface?.close()
            vpnInterface = null
            vpnThread?.interrupt()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing VPN interface", e)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVpnEngine()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Game Network Debugger Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active packet capture and game server IP drop testing"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Floating Debug - Network Filter Active")
            .setContentText("Monitoring live game connections and ready to drop IP routes")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
    }
}