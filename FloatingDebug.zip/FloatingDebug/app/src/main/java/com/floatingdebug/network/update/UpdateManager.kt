package com.floatingdebug.network.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.content.FileProvider
import com.floatingdebug.network.BuildConfig
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class UpdateInfo(
    val versionName: String,
    val notes: String,
    val apkUrl: String,
    val sizeBytes: Long
)

sealed class UpdateResult {
    /** Alamat repositori GitHub belum diketahui aplikasi. */
    object NotConfigured : UpdateResult()

    /** Versi terpasang sudah yang terbaru. */
    object UpToDate : UpdateResult()

    /** Ada versi lebih baru yang siap diunduh. */
    data class Available(val info: UpdateInfo) : UpdateResult()

    data class Error(val message: String) : UpdateResult()
}

/**
 * Pembaruan online lewat GitHub Releases.
 *
 * Cara kerja: workflow GitHub membangun APK lalu menerbitkannya sebagai "Release" bertag
 * v<versi> (mis. v1.0.1). Aplikasi membaca release terbaru, membandingkan versinya dengan versi
 * yang terpasang, mengunduh APK, lalu membuka pemasang paket Android.
 *
 * Syarat: repositori GitHub harus publik, dan APK baru harus ditandatangani dengan kunci
 * yang sama dengan versi terpasang (sudah diatur lewat release.keystore di proyek).
 */
object UpdateManager {

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private const val USER_AGENT = "FloatingDebug-Updater"

    // ---------------------------------------------------------------- cek versi

    fun checkForUpdate(onResult: (UpdateResult) -> Unit) {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) {
            mainHandler.post { onResult(UpdateResult.NotConfigured) }
            return
        }
        executor.execute {
            val result = try {
                fetchLatest(repo)
            } catch (e: Exception) {
                UpdateResult.Error(e.message ?: e.javaClass.simpleName)
            }
            mainHandler.post { onResult(result) }
        }
    }

    private fun fetchLatest(repo: String): UpdateResult {
        val conn = URL("https://api.github.com/repos/$repo/releases/latest")
            .openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 15_000
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.setRequestProperty("User-Agent", USER_AGENT)
        try {
            when (val code = conn.responseCode) {
                200 -> Unit
                404 -> return UpdateResult.Error("Belum ada rilis, atau repositori bersifat privat.")
                else -> return UpdateResult.Error("Server GitHub membalas kode $code.")
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)

            val tag = json.optString("tag_name").trim().removePrefix("v").removePrefix("V")
            val notes = json.optString("body", "")

            var apkUrl = ""
            var apkSize = 0L
            val assets = json.optJSONArray("assets")
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val asset = assets.getJSONObject(i)
                    if (asset.optString("name").endsWith(".apk", ignoreCase = true)) {
                        apkUrl = asset.optString("browser_download_url")
                        apkSize = asset.optLong("size")
                        break
                    }
                }
            }

            if (tag.isBlank() || apkUrl.isBlank()) {
                return UpdateResult.Error("Rilis terbaru tidak berisi file APK.")
            }

            return if (isNewer(tag, BuildConfig.VERSION_NAME)) {
                UpdateResult.Available(UpdateInfo(tag, notes, apkUrl, apkSize))
            } else {
                UpdateResult.UpToDate
            }
        } finally {
            conn.disconnect()
        }
    }

    /** true jika [remote] lebih baru daripada [local]; membandingkan angka per bagian (1.0.10 > 1.0.9). */
    fun isNewer(remote: String, local: String): Boolean {
        val r = parseVersion(remote)
        val l = parseVersion(local)
        val n = maxOf(r.size, l.size)
        for (i in 0 until n) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }

    private fun parseVersion(v: String): List<Int> =
        v.trim().removePrefix("v").removePrefix("V")
            .split(".", "-", "+")
            .map { part -> part.filter { it.isDigit() }.toIntOrNull() ?: 0 }

    // ---------------------------------------------------------------- unduh

    /**
     * Mengunduh APK ke cache aplikasi. Semua callback dipanggil di thread utama.
     * [onDone] menerima (file, null) jika sukses atau (null, pesanError) jika gagal.
     */
    fun download(
        context: Context,
        info: UpdateInfo,
        onProgress: (Int) -> Unit,
        onDone: (File?, String?) -> Unit
    ) {
        val appContext = context.applicationContext
        executor.execute {
            var resultFile: File? = null
            var error: String? = null
            try {
                val dir = File(appContext.cacheDir, "updates")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val target = File(dir, "FloatingDebug-${info.versionName}.apk")

                val conn = URL(info.apkUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", USER_AGENT)
                try {
                    if (conn.responseCode != 200) {
                        throw IllegalStateException("Server membalas kode ${conn.responseCode}.")
                    }
                    val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else info.sizeBytes
                    var done = 0L
                    var lastPercent = -1

                    conn.inputStream.use { input ->
                        target.outputStream().use { output ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                output.write(buffer, 0, n)
                                done += n
                                if (total > 0) {
                                    val percent = (done * 100 / total).toInt().coerceIn(0, 100)
                                    if (percent != lastPercent) {
                                        lastPercent = percent
                                        mainHandler.post { onProgress(percent) }
                                    }
                                }
                            }
                        }
                    }
                    if (total > 0 && done != total) {
                        throw IllegalStateException("Unduhan tidak lengkap ($done dari $total byte).")
                    }
                } finally {
                    conn.disconnect()
                }

                // Pastikan file benar-benar APK milik aplikasi ini
                val archive = appContext.packageManager.getPackageArchiveInfo(target.absolutePath, 0)
                if (archive == null || archive.packageName != appContext.packageName) {
                    target.delete()
                    throw IllegalStateException("File update bukan paket aplikasi ini.")
                }
                resultFile = target
            } catch (e: Exception) {
                error = e.message ?: e.javaClass.simpleName
            }
            mainHandler.post { onDone(resultFile, error) }
        }
    }

    // ---------------------------------------------------------------- pasang

    fun canInstall(context: Context): Boolean =
        context.packageManager.canRequestPackageInstalls()

    fun openInstallPermissionSettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun install(context: Context, apk: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
